import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async (req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers:{...cors,"Content-Type":"application/json"}});
 const url=Deno.env.get("SUPABASE_URL"), anon=Deno.env.get("SUPABASE_ANON_KEY"), service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), auth=req.headers.get("Authorization");
 if(!url||!anon||!service||!auth)return new Response(JSON.stringify({error:"Missing server config or auth"}),{status:500,headers:{...cors,"Content-Type":"application/json"}});
 try{
  const body=await req.json(); if(body?.confirm!==true)return new Response(JSON.stringify({error:"Explicit confirmation required"}),{status:400,headers:{...cors,"Content-Type":"application/json"}});
  const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});
  const {data:{user},error:userError}=await userClient.auth.getUser(); if(userError||!user)return new Response(JSON.stringify({error:"Valid signed-in user required"}),{status:401,headers:{...cors,"Content-Type":"application/json"}});
  const admin=createClient(url,service,{auth:{persistSession:false}});
  // Add deletion for every additional user-owned table in your schema before production.
  await admin.from("premium_entitlements").delete().eq("user_id",user.id);
  await admin.from("referral_rewards").delete().eq("user_id",user.id);
  const {error}=await admin.auth.admin.deleteUser(user.id); if(error)throw error;
  return new Response(JSON.stringify({success:true}),{status:200,headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e instanceof Error?e.message:"Deletion failed"}),{status:500,headers:{...cors,"Content-Type":"application/json"}});}
});
