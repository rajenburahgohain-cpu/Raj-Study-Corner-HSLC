-- Assamese Sahayika: Premium entitlement for ad-free access.
-- Run this in Supabase SQL Editor before testing Premium ad suppression.
-- This table must be updated only by trusted server/admin workflows (e.g. verified Play Billing backend).

create table if not exists public.premium_entitlements (
  user_id uuid primary key references auth.users(id) on delete cascade,
  expires_at timestamptz not null,
  source text not null default 'manual',
  updated_at timestamptz not null default now()
);

alter table public.premium_entitlements enable row level security;
drop policy if exists "Users can read own Premium entitlement" on public.premium_entitlements;
create policy "Users can read own Premium entitlement"
  on public.premium_entitlements for select
  using (auth.uid() = user_id);

-- No client INSERT/UPDATE/DELETE policies are created on purpose.
create or replace function public.is_my_premium_active()
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  active_now boolean := false;
begin
  if auth.uid() is null then
    return false;
  end if;

  select exists (
    select 1 from public.premium_entitlements e
    where e.user_id = auth.uid() and e.expires_at > now()
  ) into active_now;
  if active_now then return true; end if;

  -- Optional compatibility with the app's existing referral reward table, if installed.
  if to_regclass('public.referral_rewards') is not null then
    execute 'select exists (
      select 1 from public.referral_rewards r
      where r.user_id = $1
        and r.status in (''approved'', ''active'')
        and r.expires_at > now()
    )' into active_now using auth.uid();
    if active_now then return true; end if;
  end if;

  return false;
end;
$$;

revoke all on function public.is_my_premium_active() from public;
grant execute on function public.is_my_premium_active() to authenticated;
