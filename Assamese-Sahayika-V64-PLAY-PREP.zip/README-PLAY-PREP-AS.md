# Assamese Sahayika V64 — Play preparation

এই ZIP-ত source HTML, API 36 লক্ষ্য কৰা GitHub Actions workflow, Privacy Policy update, account deletion trigger আৰু Supabase Edge Function source আছে।

## GitHub-ত upload
ZIP-ৰ ভিতৰৰ বস্তুবোৰ repository root-ত ৰাখক: `index.html` root-ত; workflow কেৱল `.github/workflows/android-build.yml`-ত; `delete-account.html` root-ত; `supabase/functions/delete-account/index.ts` সঠিক path-ত। YAML কেতিয়াও `index.html` নামেৰে upload নকৰিব।

## Signing secrets (Play AAB-ৰ বাবে)
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` GitHub Secrets-ত দিব লাগিব। নাথাকিলে AAB unsigned হ’ব পাৰে আৰু Play Console-ত upload কৰিব নোৱাৰি।

## AdMob
`ADMOB_APP_ID`, `ADMOB_BANNER_UNIT_ID`, `ADMOB_INTERSTITIAL_UNIT_ID` optional secrets। এইবোৰ নাথাকিলে test IDs ব্যৱহাৰ হ’ব; test ads-ৰ পৰা আয় নহয়। Production-ৰ আগতে AdMob consent/UMP configuration আৰু actual device testing কৰক।

## Account deletion
Supabase-ত `delete-account` Edge Function deploy কৰক। Supabase server secrets (`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`) server-side-ত থাকিব লাগিব; service role key HTML-ত কেতিয়াও নাৰাখিব। `delete-account.html` GitHub Pages-ত publish কৰি সেই URL Play Console-ৰ deletion URL-ত দিব পাৰি। Function-এ `premium_entitlements`, `referral_rewards`-ৰ user-owned rows আৰু Auth user delete কৰে। আপোনাৰ schema-ত অন্য user-owned table থাকিলে production-ৰ আগতে সেইবোৰো বিবেচনা/পৰীক্ষা কৰিব লাগিব।

## Billing — blocker
Premium SQL কেৱল entitlement check কৰে; Google Play purchase নকৰে আৰু purchase token verify নকৰে। Play Billing plugin/UI, Play Console product/subscription ID আৰু server-side purchase-token verification এতিয়াও implement/verify হোৱা নাই। সেইবাবে paid Premium-ৰ বাবে এই ZIP-টোক সম্পূৰ্ণ ready বুলি নধৰিব।

## Release smoke tests
Login/signup; Search, lesson Q&A, Admin/RLS, AI/Search/Assamese-stt Edge Functions; microphone on Android; AdMob launch banner and safe interstitial; Premium ad suppression; app + external account deletion; signed AAB and API 36; Data Safety/audience/ads declaration; store listing and internal/closed testing.

**Status:** source package updated, but Android build not run here, signed AAB not verified, Edge Function not deployed, Billing not implemented, real AdMob IDs not configured, and real-device tests not done.
