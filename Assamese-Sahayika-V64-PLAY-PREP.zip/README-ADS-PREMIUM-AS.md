# Assamese Sahayika V63 — Ads and Premium setup

This package keeps the supplied V62 learning content and fixes the root HTML/workflow separation. It does not automatically modify your GitHub repository; upload these files to the repository as described below.

## Files
- `index.html`: the study app HTML, with native AdMob banner on app launch, hourly interstitial at the next normal page transition, and a Premium entitlement check that suppresses all ads for active Premium users.
- `.github/workflows/android-build.yml`: Android build workflow. It checks that `index.html` is actually HTML, prepares Capacitor 6 + AdMob, configures Android microphone permissions and the AdMob App ID, and uploads APK/AAB artifacts.
- `premium_ads_setup.sql`: Supabase SQL for a server-checked Premium entitlement. Run it in Supabase SQL Editor.

## Important behavior
- At app launch, a banner ad is requested in the native Android app.
- After 60 minutes, an interstitial is shown only at the next normal page transition, not directly on app launch or in the middle of reading a lesson.
- Premium status is checked with the Supabase `is_my_premium_active()` function. The user must be signed in and have an active server-side entitlement. If active, banner and interstitial ads are disabled.
- Google test IDs are used until all three GitHub Actions secrets are supplied: `ADMOB_APP_ID`, `ADMOB_BANNER_UNIT_ID`, and `ADMOB_INTERSTITIAL_UNIT_ID`. Test ads do not earn revenue.
- `premium_ads_setup.sql` provides the entitlement check; it does not implement or verify paid Google Play Billing. Paid Premium must only be granted by a trusted server after Google Play purchase verification. Do not grant Premium based only on a client-side flag.
- `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD` are optional GitHub secrets for signing the release AAB. Without all four, the workflow still builds an AAB, but it is unsigned and cannot be uploaded to Play Console as a release.
- Because this is an educational app that may be used by minors, review AdMob consent, age-directed ad settings, Families policies, and the app's Data Safety disclosure before serving production ads. `npa: true` is set in the ad requests, but this alone is not a substitute for required consent/configuration.

## Upload to GitHub on Android
1. Download and extract the ZIP on your phone or computer.
2. In `Raj-Study-Corner-HSLC`, replace the root `index.html` with this package's `index.html` (do not put YAML in `index.html`).
3. Open `.github/workflows/` and replace `android-build.yml` with this package's workflow. Keep the workflow file at exactly `.github/workflows/android-build.yml`.
4. Add `premium_ads_setup.sql` to the repository or keep a local copy, then run its contents in Supabase SQL Editor.
5. Commit the changes. Open GitHub Actions and run “Build Assamese Sahayika APK and AAB (AdMob Test Ads)”. Download the artifact from the completed run.
6. If the repository's current `index.html` was accidentally replaced by YAML, this package's `index.html` restores the app page.

## Do not do
- Do not paste the workflow YAML into `index.html`.
- Do not click your own production ads while testing.
- Do not put service-role keys, AI keys, or other secrets in public HTML.
